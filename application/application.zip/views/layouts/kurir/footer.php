<script src="<?= base_url() ?>public/template/js/tabler.min.js?1692870487" defer></script>
<script src="<?= base_url() ?>public/template/js/demo.min.js?1692870487" defer></script>
<script src="<?= base_url('') ?>public/template/libs/sweetalert2/sweetalert2.js" />
<script>
  navigator.serviceWorker.register("<?= base_url('') ?>public/service-worker.js")
</script>